---
name: Mahakash Shikhya
colors:
  surface: '#101415'
  surface-dim: '#101415'
  surface-bright: '#363a3b'
  surface-container-lowest: '#0b0f10'
  surface-container-low: '#191c1e'
  surface-container: '#1d2022'
  surface-container-high: '#272a2c'
  surface-container-highest: '#323537'
  on-surface: '#e0e3e5'
  on-surface-variant: '#cbc4ce'
  inverse-surface: '#e0e3e5'
  inverse-on-surface: '#2d3133'
  outline: '#958f98'
  outline-variant: '#49454d'
  surface-tint: '#d2beeb'
  primary: '#d2beeb'
  on-primary: '#38294d'
  primary-container: '#0d0121'
  on-primary-container: '#827199'
  inverse-primary: '#68577d'
  secondary: '#e6feff'
  on-secondary: '#003739'
  secondary-container: '#00f4fe'
  on-secondary-container: '#006c71'
  tertiary: '#ecb2ff'
  on-tertiary: '#520071'
  tertiary-container: '#12001d'
  on-tertiary-container: '#bf16ff'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#eddcff'
  primary-fixed-dim: '#d2beeb'
  on-primary-fixed: '#221436'
  on-primary-fixed-variant: '#4f4064'
  secondary-fixed: '#63f7ff'
  secondary-fixed-dim: '#00dce5'
  on-secondary-fixed: '#002021'
  on-secondary-fixed-variant: '#004f53'
  tertiary-fixed: '#f8d8ff'
  tertiary-fixed-dim: '#ecb2ff'
  on-tertiary-fixed: '#320047'
  on-tertiary-fixed-variant: '#74009f'
  background: '#101415'
  on-background: '#e0e3e5'
  surface-variant: '#323537'
typography:
  display-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Be Vietnam Pro
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Be Vietnam Pro
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-sm:
    fontFamily: Be Vietnam Pro
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  code-label:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.0'
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 64px
  container-max: 1280px
---

## Brand & Style
The design system embodies a "Cosmic Academy" aesthetic, merging the vastness of the universe with the precision of scientific inquiry. Designed for Bengali-medium students, it aims to evoke a sense of wonder (Mahakash) and weightlessness. 

The visual style is **Futuristic Glassmorphism**. Interfaces should feel like holographic HUDs floating in deep space. Key characteristics include:
- **Depth:** Multi-layered translucent surfaces that allow background nebulae to peek through.
- **Luminescence:** Interactive elements emit a soft glow, mimicking starlight or neon gas.
- **Technical Precision:** Subtle grid patterns and data-rich accents that reference scientific instrumentation.
- **Creator Attribution:** Brand footers and "About" sections should credit **Siraj Hossain** as the visionary architect of this educational galaxy.

## Colors
The palette is derived from deep-space photography and neon laboratory equipment.
- **Base (Deep Nebula):** `#0D0121` – A near-black purple used for the infinite background.
- **Primary Accent (Cyan Neon):** `#00F5FF` – Used for critical actions, progress bars, and "VVM Preparation" highlights. It represents scientific energy.
- **Secondary Accent (Stellar Violet):** `#BD00FF` – Used for navigational highlights and secondary interactive states.
- **Surface (Glass):** Semi-transparent variants of primary colors (e.g., `rgba(13, 1, 33, 0.7)`) with backdrop-blur.
- **Semantic White (Starlight):** `#F8FAFC` – Pure, high-contrast text for maximum readability of Bengali script against dark backgrounds.

## Typography
The system utilizes **Be Vietnam Pro** for its excellent legibility and clean, modern structure which harmonizes well with complex Bengali glyphs. It feels technical yet approachable.

**JetBrains Mono** is introduced for technical labels, mock test timers, and question ID markers to reinforce the scientific, developer-centric aesthetic of the platform.

**Rendering Notes:**
- Ensure line-height for Bengali text is slightly higher than standard English (minimum 1.5) to avoid overlapping matras.
- Use uppercase and tracking for Mono labels to create a "UI Dashboard" feel.

## Layout & Spacing
The layout follows a **Fluid HUD (Heads-Up Display)** model. 
- **Grid:** A 12-column grid for desktop, reducing to 4 columns for mobile.
- **Rhythm:** Spacing is based on a 4px scale to ensure technical precision.
- **Margins:** Generous outer margins (64px on desktop) create a "floating" effect for the central content container.
- **Safe Areas:** For Mock Tests, use a fixed-height header and footer to keep the question paper isolated in a scrollable glass container, mimicking a cockpit view.

## Elevation & Depth
Elevation is achieved through **Luminance and Blur** rather than traditional shadows.
- **Level 1 (Deep Space):** The base background with a subtle SVG noise filter to simulate star-dust.
- **Level 2 (Glass Platter):** Semi-transparent backgrounds (`#ffffff10`) with `20px` backdrop-blur and a `1px` inner border of `#ffffff20`.
- **Level 3 (Active HUD):** Elements that are interactive or "hovered" gain a `0 0 15px` outer glow using the Primary Cyan color.
- **Depth Cues:** Use radial gradients in the background to suggest distant nebulae, providing a sense of 3D space behind the flat UI planes.

## Shapes
Shapes are **Technical and Structured**. 
- **Corner Radius:** Elements use a consistent `0.25rem` (4px) radius to maintain a crisp, scientific feel. Avoid overly rounded or organic "bubbly" shapes.
- **Angled Accents:** Use 45-degree clipped corners (beveled edges) for primary buttons and section headers to reinforce the sci-fi aesthetic.
- **Stroke:** All glass containers must have a consistent `1px` solid border to define their boundaries against the dark background.

## Components
- **Primary Buttons:** High-contrast Cyan (`#00F5FF`) backgrounds with black text. On hover, apply a box-shadow glow. Use for "Start Mock Test" or "Download Question Bank."
- **Glass Cards:** Used for WBBSE Chapter lists. Background: `rgba(255, 255, 255, 0.05)`, Border: `1px solid rgba(255, 255, 255, 0.1)`, Backdrop-filter: `blur(12px)`.
- **Inputs:** Darker background than the card, with a Cyan bottom-border that glows when focused. Labels should be in JetBrains Mono.
- **Progress Trackers:** Linear bars using a gradient from Stellar Violet to Cyan.
- **Question Chips:** For the 10-year question bank, use small outlined chips with the year (e.g., "2022") in a mono font.
- **VVM Dashboard:** A specialized side-panel featuring "mission-critical" stats like rank and percentile, styled like a satellite telemetry feed.